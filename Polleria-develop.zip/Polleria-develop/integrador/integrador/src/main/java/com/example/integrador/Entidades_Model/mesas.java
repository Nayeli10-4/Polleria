
package com.example.integrador.Entidades_Model;


public class mesas {
    
}
