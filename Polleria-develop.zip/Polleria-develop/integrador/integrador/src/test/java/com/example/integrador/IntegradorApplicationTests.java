package com.example.integrador;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IntegradorApplicationTests {

	@Test
	void contextLoads() {
	}

}
